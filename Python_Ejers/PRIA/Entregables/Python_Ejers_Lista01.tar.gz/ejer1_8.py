#es lo mismo que el ejercicio 1
