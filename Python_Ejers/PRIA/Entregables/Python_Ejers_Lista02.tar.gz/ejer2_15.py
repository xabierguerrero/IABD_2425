conjunto={"*","a","z","0","A"}
conjunto=sorted(conjunto)
print(conjunto[len(conjunto)-1])