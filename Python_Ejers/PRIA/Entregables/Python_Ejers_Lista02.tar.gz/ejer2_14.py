conjunto={-2,-15,1,6,9,-50,100,200,10,20,5}
conjunto=sorted(conjunto)
print(conjunto[0])