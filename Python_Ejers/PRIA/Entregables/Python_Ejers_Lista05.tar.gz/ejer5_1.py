import re

TEXTO = """En un lugar de la Mancha, de cuyo nombre no quiero acordarme, 
no ha mucho tiempo que vivía un hidalgo de los de lanza en astillero, 
adarga antigua, rocín flaco y galgo corredor"""

palabras=re.split(r"\W+",TEXTO)
print(palabras)